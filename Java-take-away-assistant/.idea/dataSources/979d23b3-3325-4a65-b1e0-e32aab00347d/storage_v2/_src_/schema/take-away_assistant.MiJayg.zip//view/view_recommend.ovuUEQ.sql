create definer = root@localhost view view_recommend as
select `take-away assistant`.`merchandise_sort`.`Sort_name`                AS `Sort_name`,
       `take-away assistant`.`consumer_information`.`Consumer_id`          AS `Consumer_id`,
       `take-away assistant`.`order_`.`Order_id`                           AS `Order_id`,
       `take-away assistant`.`merchandise_information`.`Merchandise_name`  AS `Merchandise_name`,
       `take-away assistant`.`merchandise_information`.`Merchandise_price` AS `Merchandise_price`,
       `take-away assistant`.`merchandise_information`.`Disconut_price`    AS `Disconut_price`,
       `take-away assistant`.`merchandise_information`.`Merchandise_id`    AS `Merchandise_id`,
       `take-away assistant`.`merchandise_information`.`Merchant_id`       AS `Merchant_id`,
       `take-away assistant`.`merchandise_sort`.`Sort_id`                  AS `Sort_id`
from ((((`take-away assistant`.`order_detail` join `take-away assistant`.`order_` on ((
        `take-away assistant`.`order_detail`.`Order_id` =
        `take-away assistant`.`order_`.`Order_id`))) join `take-away assistant`.`consumer_information` on ((
        `take-away assistant`.`order_`.`Consumer_id` =
        `take-away assistant`.`consumer_information`.`Consumer_id`))) join `take-away assistant`.`merchandise_information` on ((
        `take-away assistant`.`order_detail`.`Merchandise_id` =
        `take-away assistant`.`merchandise_information`.`Merchandise_id`)))
         join `take-away assistant`.`merchandise_sort` on ((`take-away assistant`.`merchandise_information`.`Sort_id` =
                                                            `take-away assistant`.`merchandise_sort`.`Sort_id`)));

