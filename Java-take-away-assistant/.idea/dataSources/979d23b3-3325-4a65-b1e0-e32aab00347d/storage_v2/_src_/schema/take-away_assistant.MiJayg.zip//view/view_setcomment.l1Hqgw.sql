create definer = root@localhost view view_setcomment as
select `take-away assistant`.`merchant_information`.`Merchant_name`       AS `Merchant_name`,
       `take-away assistant`.`merchandise_information`.`Merchandise_name` AS `Merchandise_name`,
       `take-away assistant`.`order_`.`Order_platime`                     AS `Order_platime`,
       `take-away assistant`.`order_`.`Order_id`                          AS `Order_id`,
       `take-away assistant`.`order_`.`Consumer_id`                       AS `Consumer_id`,
       `take-away assistant`.`merchandise_information`.`Merchandise_id`   AS `Merchandise_id`,
       `take-away assistant`.`merchant_information`.`Merchant_id`         AS `Merchant_id`
from `take-away assistant`.`order_`
         join `take-away assistant`.`order_detail`
         join `take-away assistant`.`merchandise_information`
         join `take-away assistant`.`merchant_information`
where ((`take-away assistant`.`order_detail`.`Merchandise_id` =
        `take-away assistant`.`merchandise_information`.`Merchandise_id`) and
       (`take-away assistant`.`merchandise_information`.`Merchant_id` =
        `take-away assistant`.`merchant_information`.`Merchant_id`) and
       (`take-away assistant`.`order_detail`.`Order_id` = `take-away assistant`.`order_`.`Order_id`) and
       (`take-away assistant`.`order_`.`Order_state` = '已送达') and (not (exists(select 1
                                                                               from `take-away assistant`.`comment_`
                                                                               where ((`take-away assistant`.`order_detail`.`Merchandise_id` =
                                                                                       `take-away assistant`.`comment_`.`Merchandise_id`) and
                                                                                      (`take-away assistant`.`order_detail`.`Order_id` =
                                                                                       `take-away assistant`.`comment_`.`Order_id`))))));

