create definer = root@localhost view view_loadrecommend as
select `take-away assistant`.`comment_`.`Comment_picture`                 AS `Comment_picture`,
       `take-away assistant`.`comment_`.`Comment_level`                   AS `Comment_level`,
       `take-away assistant`.`comment_`.`Comment_content`                 AS `Comment_content`,
       `take-away assistant`.`comment_`.`Comment_Date`                    AS `Comment_Date`,
       `take-away assistant`.`comment_`.`Order_id`                        AS `Order_id`,
       `take-away assistant`.`merchant_information`.`Merchant_name`       AS `Merchant_name`,
       `take-away assistant`.`merchandise_information`.`Merchandise_name` AS `Merchandise_name`,
       `take-away assistant`.`merchandise_information`.`Merchant_id`      AS `Merchant_id`,
       `take-away assistant`.`consumer_information`.`Consumer_name`       AS `Consumer_name`
from (((((`take-away assistant`.`merchant_information` join `take-away assistant`.`merchandise_information` on ((
        `take-away assistant`.`merchant_information`.`Merchant_id` =
        `take-away assistant`.`merchandise_information`.`Merchant_id`))) join `take-away assistant`.`order_detail` on ((
        `take-away assistant`.`merchandise_information`.`Merchandise_id` =
        `take-away assistant`.`order_detail`.`Merchandise_id`))) join `take-away assistant`.`order_` on ((
        `take-away assistant`.`order_`.`Order_id` =
        `take-away assistant`.`order_detail`.`Order_id`))) join `take-away assistant`.`comment_` on ((
        (`take-away assistant`.`merchandise_information`.`Merchandise_id` =
         `take-away assistant`.`comment_`.`Merchandise_id`) and
        (`take-away assistant`.`order_`.`Order_id` = `take-away assistant`.`comment_`.`Order_id`))))
         join `take-away assistant`.`consumer_information` on (((`take-away assistant`.`comment_`.`Consumer_id` =
                                                                 `take-away assistant`.`consumer_information`.`Consumer_id`) and
                                                                (`take-away assistant`.`order_`.`Consumer_id` =
                                                                 `take-away assistant`.`consumer_information`.`Consumer_id`))));

