create definer = root@localhost view view_takeorder as
select `take-away assistant`.`merchant_information`.`Merchant_id`          AS `merchant_id`,
       `take-away assistant`.`merchant_information`.`Merchant_name`        AS `merchant_name`,
       `take-away assistant`.`merchant_information`.`Merchant_level`       AS `Merchant_level`,
       `take-away assistant`.`merchant_information`.`Consume_avgprice`     AS `Consume_avgprice`,
       `take-away assistant`.`merchant_information`.`Total_sales`          AS `Total_sales`,
       `take-away assistant`.`merchandise_information`.`Merchandise_id`    AS `merchandise_id`,
       `take-away assistant`.`merchandise_information`.`Merchandise_name`  AS `merchandise_name`,
       `take-away assistant`.`merchandise_information`.`Merchandise_price` AS `Merchandise_price`,
       `take-away assistant`.`merchandise_information`.`Disconut_price`    AS `Disconut_price`,
       `take-away assistant`.`merchandise_sort`.`Sort_name`                AS `Sort_name`
from `take-away assistant`.`merchant_information`
         join `take-away assistant`.`merchandise_information`
         join `take-away assistant`.`merchandise_sort`
where ((`take-away assistant`.`merchant_information`.`Merchant_id` =
        `take-away assistant`.`merchandise_information`.`Merchant_id`) and
       (`take-away assistant`.`merchandise_information`.`Sort_id` =
        `take-away assistant`.`merchandise_sort`.`Sort_id`));

