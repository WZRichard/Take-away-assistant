create definer = root@localhost view view_havingcoupon as
select `take-away assistant`.`collect_to_get`.`Consumer_id`         AS `Consumer_id`,
       `take-away assistant`.`merchant_information`.`Merchant_name` AS `Merchant_name`,
       `take-away assistant`.`discount_coupon`.`Discount_price`     AS `Discount_price`,
       `take-away assistant`.`discount_coupon`.`Order_count`        AS `Order_count`,
       `take-away assistant`.`collect_to_get`.`Collect_now`         AS `Collect_now`,
       `take-away assistant`.`discount_coupon`.`Starttime`          AS `Starttime`,
       `take-away assistant`.`discount_coupon`.`Finishtime`         AS `Finishtime`
from `take-away assistant`.`consumer_information`
         join `take-away assistant`.`merchant_information`
         join `take-away assistant`.`collect_to_get`
         join `take-away assistant`.`discount_coupon`
where ((`take-away assistant`.`merchant_information`.`Merchant_id` =
        `take-away assistant`.`collect_to_get`.`Merchant_id`) and
       (`take-away assistant`.`collect_to_get`.`Consumer_id` =
        `take-away assistant`.`consumer_information`.`Consumer_id`) and
       (`take-away assistant`.`collect_to_get`.`Coupon_id` = `take-away assistant`.`discount_coupon`.`Coupon_id`) and
       (`take-away assistant`.`discount_coupon`.`Finishtime` >= (select now())));

