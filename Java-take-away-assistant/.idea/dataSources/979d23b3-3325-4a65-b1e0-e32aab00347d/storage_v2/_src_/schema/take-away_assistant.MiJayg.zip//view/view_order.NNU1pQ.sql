create definer = root@localhost view view_order as
select `take-away assistant`.`order_`.`Order_id`                          AS `Order_id`,
       `take-away assistant`.`consumer_information`.`Consumer_id`         AS `Consumer_id`,
       `take-away assistant`.`consumer_information`.`Consumer_name`       AS `Consumer_name`,
       `take-away assistant`.`merchant_information`.`Merchant_id`         AS `Merchant_id`,
       `take-away assistant`.`merchant_information`.`Merchant_name`       AS `Merchant_name`,
       `take-away assistant`.`merchandise_information`.`Merchandise_name` AS `Merchandise_name`,
       `take-away assistant`.`order_detail`.`Merchandise_Count`           AS `Merchandise_Count`,
       `take-away assistant`.`order_`.`Order_state`                       AS `Order_state`,
       `take-away assistant`.`order_`.`Order_platime`                     AS `Order_platime`,
       `take-away assistant`.`order_`.`Order_deltime`                     AS `Order_deltime`,
       `take-away assistant`.`delivery_address`.`Address_province`        AS `Address_province`,
       `take-away assistant`.`delivery_address`.`Address_city`            AS `Address_city`,
       `take-away assistant`.`delivery_address`.`Address_region`          AS `Address_region`,
       `take-away assistant`.`delivery_address`.`Address_add`             AS `Address_add`,
       `take-away assistant`.`delivery_address`.`Address_linkman`         AS `Address_linkman`,
       `take-away assistant`.`delivery_address`.`Address_phonenum`        AS `Address_phonenum`,
       `take-away assistant`.`order_`.`Comment_Rider`                     AS `Comment_Rider`,
       `take-away assistant`.`order_`.`Rider_id`                          AS `Rider_id`
from `take-away assistant`.`order_`
         join `take-away assistant`.`order_detail`
         join `take-away assistant`.`consumer_information`
         join `take-away assistant`.`merchandise_information`
         join `take-away assistant`.`delivery_address`
         join `take-away assistant`.`merchant_information`
where ((`take-away assistant`.`order_`.`Consumer_id` = `take-away assistant`.`consumer_information`.`Consumer_id`) and
       (`take-away assistant`.`order_`.`Order_id` = `take-away assistant`.`order_detail`.`Order_id`) and
       (`take-away assistant`.`order_detail`.`Merchandise_id` =
        `take-away assistant`.`merchandise_information`.`Merchandise_id`) and
       (`take-away assistant`.`merchant_information`.`Merchant_id` =
        `take-away assistant`.`merchandise_information`.`Merchant_id`) and
       (`take-away assistant`.`order_`.`Address_id` = `take-away assistant`.`delivery_address`.`Address_id`));

