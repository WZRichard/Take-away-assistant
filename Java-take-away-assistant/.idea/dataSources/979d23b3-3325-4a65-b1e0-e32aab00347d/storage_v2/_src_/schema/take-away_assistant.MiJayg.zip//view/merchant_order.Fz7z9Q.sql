create definer = root@localhost view merchant_order as
select `take-away assistant`.`order_`.`Order_id`                           AS `Order_id`,
       `take-away assistant`.`merchant_information`.`Merchant_id`          AS `Merchant_id`,
       `take-away assistant`.`merchant_information`.`Total_sales`          AS `Total_sales`,
       `take-away assistant`.`merchant_information`.`Consume_avgprice`     AS `Consume_avgprice`,
       `take-away assistant`.`merchant_information`.`Merchant_name`        AS `Merchant_name`,
       `take-away assistant`.`merchandise_information`.`Merchandise_id`    AS `Merchandise_id`,
       `take-away assistant`.`merchandise_information`.`Merchandise_name`  AS `Merchandise_name`,
       `take-away assistant`.`merchandise_information`.`Merchandise_price` AS `Merchandise_price`
from (((`take-away assistant`.`order_` join `take-away assistant`.`order_detail` on ((
        `take-away assistant`.`order_`.`Order_id` =
        `take-away assistant`.`order_detail`.`Order_id`))) join `take-away assistant`.`merchandise_information` on ((
        `take-away assistant`.`order_detail`.`Merchandise_id` =
        `take-away assistant`.`merchandise_information`.`Merchandise_id`)))
         join `take-away assistant`.`merchant_information`
              on ((`take-away assistant`.`merchant_information`.`Merchant_id` =
                   `take-away assistant`.`merchandise_information`.`Merchant_id`)));

