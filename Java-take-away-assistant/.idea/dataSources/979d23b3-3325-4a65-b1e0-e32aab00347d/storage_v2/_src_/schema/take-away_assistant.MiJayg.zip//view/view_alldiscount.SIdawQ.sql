create definer = root@localhost view view_alldiscount as
select `take-away assistant`.`consumer_information`.`Consumer_id` AS `Consumer_id`,
       `take-away assistant`.`merchant_information`.`Merchant_id` AS `Merchant_id`,
       `take-away assistant`.`full_reduction`.`Reduction_id`      AS `Reduction_id`,
       `take-away assistant`.`discount_coupon`.`Coupon_id`        AS `Coupon_id`,
       `take-away assistant`.`full_reduction`.`Red_Amount`        AS `Red_Amount`,
       `take-away assistant`.`full_reduction`.`Red_Aim`           AS `Red_Aim`,
       `take-away assistant`.`discount_coupon`.`Discount_price`   AS `Discount_price`,
       `take-away assistant`.`discount_coupon`.`Order_count`      AS `Order_count`
from `take-away assistant`.`consumer_information`
         join `take-away assistant`.`merchant_information`
         join `take-away assistant`.`collect_to_get`
         join `take-away assistant`.`full_reduction`
         join `take-away assistant`.`discount_coupon`
where ((`take-away assistant`.`merchant_information`.`Merchant_id` =
        `take-away assistant`.`full_reduction`.`Merchant_id`) and
       (`take-away assistant`.`merchant_information`.`Merchant_id` =
        `take-away assistant`.`collect_to_get`.`Merchant_id`) and
       (`take-away assistant`.`merchant_information`.`Merchant_id` =
        `take-away assistant`.`collect_to_get`.`Merchant_id`) and
       (`take-away assistant`.`collect_to_get`.`Consumer_id` =
        `take-away assistant`.`consumer_information`.`Consumer_id`) and
       (`take-away assistant`.`full_reduction`.`Support_coupon` = TRUE) and
       (`take-away assistant`.`collect_to_get`.`Coupon_id` = `take-away assistant`.`discount_coupon`.`Coupon_id`) and
       (`take-away assistant`.`collect_to_get`.`Collect_now` >= `take-away assistant`.`discount_coupon`.`Order_count`));

